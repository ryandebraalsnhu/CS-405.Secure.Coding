// Exceptions.cpp:      This file contains the 'main' function. Program execution begins and ends there.
// Author:              Ryan DeBraal
// Course:              CS-405-X6389 Secure Coding 21EW6
// Instructions:        All code modifications have been marked with a "//FIX:" comment. 

#include <iostream>

using namespace std;

//FIX: Declare CustomException which is derived from std::exception
struct CustomException : public std::exception
{
    virtual const char* what() const throw()
    {
        return "A custom exception was thrown.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    //TODO: Throw any standard exception
    //FIX:
    throw std::exception("A standard exception was thrown.");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    //TODO: Wrap the call to do_even_more_custom_application_logic() with an exception handler that catches 
    //std::exception, displays a message and the exception.what(), then continues processing

    //FIX:
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "ERROR: " << e.what() << std::endl;
    }

    //TODO: Throw a custom exception derived from std::exception and catch it explictly in main

    //FIX:
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    //TODO: Throw an exception to deal with divide by zero errors using a standard C++ defined exception

    //FIX:
    if (den == 0)
        throw std::runtime_error("A runtime error was thrown due to attempted division by zero.");

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //TODO: create an exception handler to capture ONLY the exception thrown by divide.

    //FIX:
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e)
    {
        std::cerr << "ERROR: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //TODO: Create exception handlers that catches (in this order): [your custom exception, std::exception, uncaught exception] 
    //that wraps the whole main function, and displays a message to the console.

    //FIX:
    try
    {   
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        std::cerr << "ERROR: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "ERROR: " << e.what() << std::endl;
    }
    catch (...) //catch-all handler
    {
        std::cerr << "ERROR: An unknown exception has occured." << std::endl;
    }

    //FIX: Pause before exiting
    std::cout << std::endl << "Press <Enter> to exit...";
    std::cin.get();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
//{"mode":"full", "isActive" : false}nn